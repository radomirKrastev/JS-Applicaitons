export let htmlData = {
  angler: () => document.querySelector("#addForm .angler"),
  weigth: () => document.querySelector("#addForm .weight"),
  species: () => document.querySelector("#addForm .species"),
  location: () => document.querySelector("#addForm .location"),
  bait: () => document.querySelector("#addForm .bait"),
  captureTime: () => document.querySelector("#addForm .captureTime"),
  catches: () => document.querySelector("#catches")
};
